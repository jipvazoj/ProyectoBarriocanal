-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 20-01-2020 a las 19:57:03
-- Versión del servidor: 10.3.16-MariaDB
-- Versión de PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `id10866138_quiz`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `ID` int(11) NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `enunciado` text COLLATE utf8_unicode_ci NOT NULL,
  `r_correcta` text COLLATE utf8_unicode_ci NOT NULL,
  `r_in1` text COLLATE utf8_unicode_ci NOT NULL,
  `r_in2` text COLLATE utf8_unicode_ci NOT NULL,
  `r_in3` text COLLATE utf8_unicode_ci NOT NULL,
  `complejidad` int(1) NOT NULL,
  `tema` text COLLATE utf8_unicode_ci NOT NULL,
  `img` blob NOT NULL,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`ID`, `email`, `enunciado`, `r_correcta`, `r_in1`, `r_in2`, `r_in3`, `complejidad`, `tema`, `img`, `likes`, `dislikes`) VALUES
(1, 'ibarriocanal003@ikasle.ehu.eus', '¿Cuál de los siguientes es un lenguaje de programación?', 'PHP', 'JSP', 'HTML', 'CSS', 1, 'Lenguajes', 0x3031323031382d4a6176614c656e6775616a6550726f6772616d6163696f6e2e6a7067, 1, 0),
(3, 'ibarriocanal003@ikasle.ehu.eus', '¿Cuál es la forma correcta de incluir un fichero en PHP?', 'Todas son correctas.', 'include \"fichero\";', 'include (\"fichero\");', 'require \"fichero\";', 2, 'PHP', 0x322e6a7067, 0, 0),
(4, 'ibarriocanal003@ikasle.ehu.eus', '¿Cuál es la forma correcta de abrir una conexión con MySql en PHP?', 'mysqli_connect(\"localhost\");', 'mysqli_open(\"localhost\");', 'dbopen(\"localhost\");', 'connect_mysqli(\"localhost\");', 2, 'PHP', 0x322e6a7067, 0, 0),
(5, 'ibarriocanal003@ikasle.ehu.eus', '¿Cuál de las siguientes afirmaciones sobre XML es correcta?', 'XML es un metalenguaje que se emplea para definir otros lenguajes.', 'XML es una extensión multidocumento de HTML.', 'XML es una versión ligera de XHTML.', 'Ninguna es correcta.', 3, 'XML', 0x332e706e67, 0, 0),
(6, 'ibarriocanal003@ikasle.ehu.eus', '¿Qué significa CSS?', 'Cascading Style Sheets', 'Creative Style Sheets', 'Computer Style Sheets', 'Colorful Style Sheets', 2, 'CSS', 0x342e706e67, 0, 0),
(7, 'ibarriocanal003@ikasle.ehu.eus', '¿Cuál es la instrucción CSS para que el texto aparezca en negrita?', 'font-weight:bold', 'font:b', 'style:bold', 'text:bold', 2, 'CSS', 0x342e706e67, 0, 0),
(8, 'ibarriocanal003@ikasle.ehu.eus', '¿Por qué símbolo comienzan todas las variables en PHP?', '$', '!', 'var', '#', 1, 'PHP', 0x322e6a7067, 0, 0),
(9, 'ibarriocanal003@ikasle.ehu.eus', '¿Para qué se utiliza el atributo alt en HTML?', 'Establecer el texto alternativo de una imagen.', 'Indicar la URL de una imagen en un formato alternativo.', 'Indicar la URL de una página web donde se proporciona una descripción larga de una imagen.', 'Ninguna es correcta.', 2, 'HTML', 0x362e6a7067, 0, 0),
(10, 'ibarriocanal003@ikasle.ehu.eus', 'Al pulsar el botón submit de un formulario HTML, los datos introducidos se envía a la URL indicada en el atributo del formulario llamado...', 'Ninguna es correcta.', 'method', 'post', 'target', 3, 'HTML', 0x362e6a7067, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resultados`
--

CREATE TABLE `resultados` (
  `nombre` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `aciertos` int(11) NOT NULL,
  `fallos` int(11) NOT NULL,
  `porcentaje` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `resultados`
--

INSERT INTO `resultados` (`nombre`, `aciertos`, `fallos`, `porcentaje`) VALUES
('PRO', 4, 3, 0.571429),
('XXX', 8, 1, 0.888889),
('YGG', 3, 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `ID` int(11) NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `tipo` int(1) NOT NULL,
  `estado` int(1) NOT NULL,
  `imagen` blob NOT NULL DEFAULT '\'noimage.png\''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`ID`, `email`, `nombre`, `password`, `tipo`, `estado`, `imagen`) VALUES
(45, 'ibarriocanal003@ikasle.ehu.eus', 'Nacho Barriocanal', 'SW0GzO5O5yEWE', 1, 1, ''),
(47, 'admin@ehu.es', 'Admin Admin', 'SWtz15iVrJRyg', 3, 1, 0x53637265656e5f53686f745f323031382d30362d30375f61745f31372e31332e34355f6772616e64652e706e67),
(49, 'vadillo@ehu.es', 'JOSE ANGEL', 'SW.9I49z6hJO2', 2, 1, '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `resultados`
--
ALTER TABLE `resultados`
  ADD PRIMARY KEY (`nombre`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
